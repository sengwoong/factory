package facroyinto;
public interface ItemFromMenu {
    String getName();
    int getPrice();
    String getPhoto();
}