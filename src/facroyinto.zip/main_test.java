package facroyinto;
import java.util.ArrayList;
import java.util.List;

public class main_test {

	 public static void main(String[] args) {
	        List<ItemFromMenu> items = new ArrayList<>();
	        items.add(ItemFactory.createItem("Product 1", 9, "photo1"));
	        items.add(ItemFactory.createItem("Product 2", 19, "photo2"));
	        items.add(ItemFactory.createItem("Product 3", 29, "photo3"));

	        ItemPrinter.printAllitems(items);
	    }

}
	